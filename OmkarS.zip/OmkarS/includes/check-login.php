<?php

function check_login()
{
    // Start or resume the session
    // session_start();

    // Check if the user is not logged in
    if (!isset($_SESSION['id']) || empty($_SESSION['id'])) {
        // User is not logged in; redirect to the login page
        $host = $_SERVER['HTTP_HOST'];
        $uri = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        $extra = "index.php"; // Change this to the actual login page

        // Redirect to the login page
        header("Location: http://$host$uri/$extra");
        exit(); // Terminate the script to prevent further execution
    }
}



?>