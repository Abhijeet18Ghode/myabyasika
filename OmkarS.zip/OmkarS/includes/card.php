<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Hostel Management System</title>
    <!-- Custom CSS -->
    <link href="../assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="../assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../dist/css/style.min.css" rel="stylesheet">
    <!-- Include html2pdf -->
    <script src="https://raw.githack.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>
    <style>
        .id-card {
            background: #ffffff;
            width: 100%; /* Updated to be responsive */
            max-width: 400px; /* Added max-width */
            margin: 0 auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .id-card img.profile-img {
            width: 100px;
            height: 100px;
            border-radius: 10px;
            box-shadow: 6px 6px 10px #888888;
            border: 3px solid white;
            object-fit: cover;
        }

        .id-card img.logo-img {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 10px; /* Added margin for spacing */
        }

        .id-card .title {
            font-size: 24px; /* Increased font size */
            font-weight: bold;
            color: #000000;
            margin-top: 10px;
            border-bottom: 2px solid #000; /* Added border */
            padding-bottom: 5px; /* Added padding */
            text-align: center; /* Center text */
        }

        .id-card .divider {
            width: 100%;
            height: 1px;
            background-color: #000;
            margin: 10px 0;
        }

        .id-card .form-group {
            margin-top: 10px;
            width: 100%;
        }

        .id-card .form-group input {
            width: 100%;
            border: none;
            background: transparent;
            border-bottom: 2px solid #000;
            color: #000;
            padding: 5px;
        }

        /* Style for the print button */
        .print-button {
            margin-top: 15px;
            padding: 10px 20px;
            background-color: #27ae60;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .address {
            font-size: 14px;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <?php
    // Assuming you have database connection logic here
    $aid = $_SESSION['login'];
    $ret = "SELECT * from registration where emailid=?";
    $stmt = $mysqli->prepare($ret);
    $stmt->bind_param('s', $aid);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_object();
    ?>

    <div class="id-card" id="idCard">
        <div>
            <img src='../assets/images/guru.png' class="logo-img">&nbsp;
            <?php
            // Get the domain name of the current website
            $currentDomain = $_SERVER['HTTP_HOST'];
            ?>
            <span class="title">Guru Abhyasika</span><br>
        </div>
        <h6 class="address">Uttam Moti Building, Sadashiv Peth, Pune - 411030 (Nr Shanipar)</h6>

        <div class="divider"></div>
        <img src='<?php echo $row->profile; ?>' class="profile-img">
        <form>
        <div class="form-group">
                <input type="text" name="gender" id="gender" class="form-control" value="<?php echo $row->roomno; ?>"
                    placeholder="Gender" readonly style="text-align: center;">
            </div>
            <div class="form-group">
                <input type="text" name="fname" id="fname" class="form-control"
                    value="<?php echo $row->firstName . ' ' . $row->middleName . ' ' . $row->lastName; ?>"
                    placeholder="Full Name" required="required" readonly>
            </div>
            <div class="form-group">
                <input type="text" name="gender" id="gender" class="form-control" value="<?php echo $row->gender; ?>"
                    placeholder="Gender" readonly>
            </div>
            <div class="form-group">
                <input type="text" name="email" id="email" class="form-control" value="<?php echo $row->emailid; ?>"
                    placeholder="Email Address" readonly>
            </div>
            <div class="form-group">
                <input type="text" name="contact" id="contact" class="form-control" value="<?php echo $row->contactno; ?>"
                    placeholder="Contact Number" required="required" readonly>
            </div>
        </form>
        <!-- Add a print button -->
        <button class="print-button" onclick="printIDCard()">Print ID Card</button>
    </div>

    <script>
        function printIDCard() {
            var element = document.getElementById('idCard');
            html2pdf(element);
        }
    </script>
</body>

</html>
