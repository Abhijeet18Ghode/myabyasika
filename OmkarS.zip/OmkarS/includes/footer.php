<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - Abhyasika Management System - Developed by <a href="https://aabhyasika.com">ADVAIT</a>
</footer>