<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Hostel Management System</title>
    <!-- Custom CSS -->
    <link href="../assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="../assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../dist/css/style.min.css" rel="stylesheet">
    <style>
        .id-card {
            background: linear-gradient(135deg, #3498db, #e74c3c);
            width: 300px;
            margin: 0 auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 12px 20px rgba(0, 0, 0, 0.2);
        }
        .id-card img {
            max-width: 100%;
            /* border: 1px solid #ccc; */
            border-radius: 50%;
            margin-top: -45px;
            box-shadow: 6px 6px 10px #888888;
             border: 3px solid white;
        }
        .id-card .title {
            font-size: 20px;
            font-weight: bold;
            margin-top: 20px;
            color: #fff;
        }
        .id-card .form-group {
            margin-top: 15px;
        }
        .id-card .form-group input {
            width: 100%;
            border: none;
            background: transparent;
            border-bottom: 2px solid #fff;
            color: #fff;
        }
        .id-card .form-actions {
            text-align: center;
            margin-top: 20px;
        }
        .id-card .btn-success {
            background: #27ae60;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <div class="id-card">
        <div class="text-center">

        <?php	
                                    $aid=$_SESSION['login'];
                                    $ret="SELECT * from registration where emailid=?";
                                    $stmt= $mysqli->prepare($ret) ;
                                    $stmt->bind_param('s',$aid);
                                    $stmt->execute() ;
                                    $res=$stmt->get_result();
                                    $cnt=1;
                                    while($row=$res->fetch_object())
                                        {
                                            ?>	

<img src='../student/<?php echo $row->profile; ?>' height='100px' width='100px style='border-radius: 50%;'>

<?php
                }
                $stmt->close();
                ?>


            
        </div>
        <h4 class="title text-center"><?php
    // Get the domain name of the current website
    $currentDomain = $_SERVER['HTTP_HOST'];
    ?>

    <?php echo $currentDomain; ?></h4>
        <form>
        <?php
            $aid = $_SESSION['id'];
            $ret = "select * from userregistration where id=?";
            $stmt = $mysqli->prepare($ret);
            $stmt->bind_param('i', $aid);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_object()) {
        ?>
            <div class="form-group">
                <input type="text" name="fname" id="fname" class="form-control" value="<?php echo $row->firstName; ?> &nbsp;<?php echo $row->middleName; ?> &nbsp;<?php echo $row->lastName; ?>" placeholder="Full Name" required="required" readonly>
            </div>
            <div class="form-group">
                <input type="text" name="gender" id="gender" class="form-control" value="<?php echo $row->gender; ?>" placeholder="Gender" readonly>
            </div>
            <div class="form-group">
                <input type="text" name="email" id="email" class="form-control" value="<?php echo $row->email; ?>" placeholder="Email Address" readonly>
            </div>
            <div class="form-group">
                <input type="text" name="contact" id="contact" class="form-control" value="<?php echo $row->contactNo; ?>" placeholder="Contact Number" required="required" readonly>
            </div>

        <?php } ?>


        <div class="form-group">
            </div>
        </form>
    </div>
 
</body>
</html>
