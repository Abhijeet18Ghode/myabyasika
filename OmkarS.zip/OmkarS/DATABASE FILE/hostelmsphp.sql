-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2023 at 12:34 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.0.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hostelmsphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(300) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updation_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `email`, `password`, `reg_date`, `updation_date`) VALUES
(1, 'Abhijeet5', 'admin@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2020-09-08 20:31:45', '2023-11-11'),
(2, 'Abhijeet', 'abhijeet@gmail.com', 'Pass@13323', '2023-10-29 05:12:48', '2023-10-29');

-- --------------------------------------------------------

--
-- Table structure for table `adminlog`
--

CREATE TABLE `adminlog` (
  `id` int(11) NOT NULL,
  `adminid` int(11) NOT NULL,
  `ip` varbinary(16) NOT NULL,
  `logintime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `course_sn` varchar(255) NOT NULL,
  `course_fn` varchar(255) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_code`, `course_sn`, `course_fn`, `posting_date`) VALUES
(1, 'BTH123', 'B.Tech', 'Bachelor  Of Technology', '2020-09-23 00:45:13'),
(2, 'BCOM18', 'B.Com', 'Bachelor Of Commerce ', '2020-09-23 00:45:13'),
(3, 'BSC296', 'BSC', 'Bachelor  of Science', '2020-09-23 00:45:13'),
(4, 'BCOA55', 'BCA', 'Bachelor Of Computer Application', '2020-09-23 00:45:13'),
(5, 'MCA001', 'MCA', 'Master of Computer Application', '2020-09-23 00:47:13'),
(6, 'MBA777', 'MBA', 'Master In Business Administration', '2020-09-23 00:54:13'),
(7, 'BE069', 'BE', 'Bachelor of Engineering', '2020-09-23 00:59:13'),
(8, 'BIT353', 'BIT', 'Bachelors In Information Technology', '2021-03-07 06:59:05'),
(9, 'MIT005', 'MIT', 'Master of Information Technology', '2022-04-03 13:03:19');

-- --------------------------------------------------------

--
-- Table structure for table `fee_list`
--

CREATE TABLE `fee_list` (
  `id` int(11) NOT NULL,
  `amount_from` float NOT NULL DEFAULT 0,
  `amount_to` float NOT NULL DEFAULT 0,
  `fee` float NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fee_list`
--

INSERT INTO `fee_list` (`id`, `amount_from`, `amount_to`, `fee`, `date_created`) VALUES
(1, 0.01, 5000, 15, '2021-10-29 10:05:56'),
(2, 5001, 10000, 25, '2021-10-29 10:06:34'),
(3, 10001, 25000, 35, '2021-10-29 10:06:56'),
(4, 25001, 1000000000000, 50, '2021-10-29 10:07:16');

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `id` int(11) NOT NULL,
  `firstName` varchar(500) NOT NULL,
  `middleName` varchar(500) NOT NULL,
  `lastName` varchar(500) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `amount` int(11) NOT NULL,
  `payment_status` enum('paid','pending') NOT NULL,
  `payment_date` date NOT NULL,
  `payment_mode` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_details`
--

INSERT INTO `payment_details` (`id`, `firstName`, `middleName`, `lastName`, `contactno`, `emailid`, `amount`, `payment_status`, `payment_date`, `payment_mode`) VALUES
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', '0'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', '0'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', '0'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(30, 'Bhishma', 'Shantanu', '', 8530417169, 'bhishma@gmail.com', 1200000, 'paid', '2023-12-30', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online(paytm)'),
(30, 'Bhishma', 'Shantanu', '', 8530417169, 'bhishma@gmail.com', 12000, 'paid', '2023-10-25', 'online'),
(30, 'Bhishma', 'Shantanu', '', 8530417169, 'bhishma@gmail.com', 12000, 'paid', '2023-10-28', 'online(paytm)'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(21, 'shahrukh', 'king', '', 8530417169, 'king@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(30, 'Bhishma', 'Shantanu', '', 8530417169, 'bhishma@gmail.com', 5000, 'paid', '2023-10-29', 'online'),
(22, 'akshay', 'kumar', '', 8530417152, 'akshay@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(22, 'akshay', 'kumar', '', 8530417152, 'akshay@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(22, 'akshay', 'kumar', '', 8530417152, 'akshay@gmail.com', 12000, 'paid', '2023-10-28', 'online'),
(22, 'akshay', 'kumar', '', 8530417152, 'akshay@gmail.com', 2147483647, 'paid', '2023-10-01', 'online(paytm....)'),
(22, 'akshay', 'kumar', '', 8530417152, 'akshay@gmail.com', 12000, '', '2022-02-28', 'online wqwer'),
(31, 'Rahul', 'k', '', 8530417169, 'rahul@gmail.com', 12000, 'paid', '2023-10-29', 'online(paytm....)'),
(31, 'Rahul', 'k', '', 8530417169, 'rahul@gmail.com', 12000, 'paid', '2023-10-25', 'online(paytm)'),
(32, 'Rahul', 'k', '', 8530417169, 'rahul@gmail.com', 12000, 'paid', '2023-11-09', 'online(paytm)'),
(30, 'Bhishma', 'Shantanu', '', 8530417169, 'bhishma@gmail.com', 12000, 'paid', '2023-11-10', 'online(paytm)'),
(32, 'Rahul', 'k', '', 8530417169, 'rahul@gmail.com', 2000, 'paid', '2023-11-10', 'Online '),
(33, 'shahrukh', 'king', '', 8530417169, 'king1@gmail.com', 12000, 'paid', '2023-11-10', 'online(paytm....)'),
(33, 'shahrukh', 'king', '', 8530417169, 'king1@gmail.com', 12000, 'paid', '2023-11-10', 'online(paytm)'),
(30, 'Bhishma', 'Shantanu', '', 8530417169, 'bhishma@gmail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(30, 'Bhishma', 'Shantanu', '', 8530417169, 'bhishma@gmail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(34, 'Omkar ', 'Rajendra', '', 7058817283, 'omkardahiphale75@gmail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(39, 'Omkar', 'Rajebhau', '', 8530417169, 'omk@gmail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(35, 'Ganesh', 'Revansiddha', '', 8530417169, 'ganeshsaddu06@gmail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(40, 'Ajit', 'Amarsing', '', 9404481094, 'ajit.javheri@yahoomail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(34, 'Omkar ', 'Rajendra', '', 7058817283, 'omkardahiphale75@gmail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(41, 'Ganesh', 'Revansiddh', '', 8530417169, 'ganeshs@gmail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(34, 'Omkar ', 'Rajendra', '', 7058817283, 'omkardahiphale75@gmail.com', 12000, 'paid', '2023-11-11', 'online(paytm)'),
(61, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 12000, 'paid', '2023-11-12', 'online(paytm)'),
(61, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 12000, 'paid', '2301-02-12', 'online'),
(61, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 12000, 'paid', '2023-11-18', 'online(paytm)'),
(61, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 12000, 'paid', '2023-11-12', 'online'),
(63, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 12000, 'paid', '2023-11-13', 'online'),
(62, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 12000, 'paid', '2023-11-13', 'online(paytm)'),
(62, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 12000, 'paid', '2023-11-13', 'online(paytm)'),
(63, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 12000, 'paid', '2023-11-13', 'online'),
(62, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 910, 'paid', '2023-11-13', 'online'),
(62, 'karan', 'ram', 'metha', 8530417169, 'kr@gmail.com', 910, 'paid', '2023-11-13', 'cash');

-- --------------------------------------------------------

--
-- Table structure for table `payment_status`
--

CREATE TABLE `payment_status` (
  `id` int(11) NOT NULL,
  `firstName` varchar(500) NOT NULL,
  `middleName` varchar(500) NOT NULL,
  `lastName` varchar(500) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `amount` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `payment_status` enum('paid','pending') NOT NULL,
  `payment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `profile` varchar(500) NOT NULL,
  `adharphoto` varchar(500) NOT NULL,
  `roomno` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `feespm` int(11) NOT NULL,
  `foodstatus` int(11) NOT NULL,
  `stayfrom` date NOT NULL,
  `dob` date NOT NULL,
  `duration` int(11) NOT NULL,
  `course` varchar(500) NOT NULL,
  `firstName` varchar(500) NOT NULL,
  `middleName` varchar(500) NOT NULL,
  `lastName` varchar(500) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `egycontactno` bigint(11) NOT NULL,
  `guardianName` varchar(500) NOT NULL,
  `guardianRelation` varchar(500) NOT NULL,
  `guardianContactno` bigint(11) NOT NULL,
  `corresAddress` varchar(500) NOT NULL,
  `corresCIty` varchar(500) NOT NULL,
  `corresState` varchar(500) NOT NULL,
  `corresPincode` int(11) NOT NULL,
  `pmntAddress` varchar(500) NOT NULL,
  `pmntCity` varchar(500) NOT NULL,
  `pmnatetState` varchar(500) NOT NULL,
  `pmntPincode` int(11) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(500) NOT NULL,
  `subscription_status` enum('paid','unpaid') NOT NULL DEFAULT 'unpaid',
  `subscription_start_date` date DEFAULT NULL,
  `subscription_end_date` date DEFAULT NULL,
  `payment_status` enum('paid','unpaid') NOT NULL DEFAULT 'unpaid',
  UNIQUE (roomno)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `profile`, `adharphoto`, `roomno`, `seater`, `feespm`, `foodstatus`, `stayfrom`, `dob`, `duration`, `course`, `firstName`, `middleName`, `lastName`, `gender`, `contactno`, `emailid`, `egycontactno`, `guardianName`, `guardianRelation`, `guardianContactno`, `corresAddress`, `corresCIty`, `corresState`, `corresPincode`, `pmntAddress`, `pmntCity`, `pmnatetState`, `pmntPincode`, `postingDate`, `updationDate`, `subscription_status`, `subscription_start_date`, `subscription_end_date`, `payment_status`) VALUES
(22, 'profile/Screenshot 2023-08-23 223605.png', '', 200, 0, 0, 0, '2023-10-25', '0000-00-00', 0, '', 'akshay', 'kumar', 'khiladi', '', 8530417152, '', 0, '', '', 0, '', '', '', 0, '', '', '', 0, '2023-11-13 10:45:57', '', 'unpaid', NULL, NULL, 'unpaid'),
(26, 'profile/2022-01-28.png', 'adhar/2022-01-29 (1).png', 269, 0, 0, 0, '2023-10-28', '0000-00-00', 0, '', 'Nitesh', 'Sunil', 'Ghode', '', 8530417169, '', 0, '', '', 0, '', '', '', 0, '', '', '', 0, '2023-11-13 10:51:54', '', 'unpaid', NULL, NULL, 'unpaid'),
(32, 'profile/th.jpg', 'adhar/th.jpg', 21, 0, 0, 0, '2023-10-29', '0000-00-00', 0, '', 'Rahul', 'k', 'Malhotra', '', 8530417169, 'rahul@gmail.com', 0, 'qjw', '', 3422525, 'bbbbbbbbbbbbbbbnnnnnnnnhhhhh', '', '', 0, 'bbbbbbbbbbbbbbbnnnnnnnnhhhhh', '', '', 0, '2023-11-13 10:42:18', '', 'unpaid', NULL, NULL, 'unpaid'),
(35, 'profile/IMG-20231109-WA0001.jpg', 'adhar/IMG-20231108-WA0007.jpg', 310, 0, 0, 0, '2023-11-11', '0000-00-00', 0, '', 'Ganesh', 'Revansiddha', 'Saddu', '', 8530417169, 'ganeshsaddu06@gmail.com', 0, 'Revansiddha Saddu', '', 876645798, 'Solapur', '', '', 0, 'Solapur', '', '', 0, '2023-11-13 11:24:42', '', 'unpaid', NULL, NULL, 'unpaid'),
(39, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 200, 0, 0, 0, '2023-11-11', '0000-00-00', 0, '', 'Omkar', 'Rajebhau', 'Dahiphale', '', 8530417169, 'omk@gmail.com', 0, 'Rajebhau', '', 63278881, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', '', '', 0, '2023-11-13 11:21:56', '', 'unpaid', NULL, NULL, 'unpaid'),
(66, 'profile/IMG-20231026-WA0017.jpg', '', 201, 0, 0, 0, '2023-10-26', '0000-00-00', 0, '', 'shahrukh', 'king', 'khan', '', 8530417169, '', 0, '', '', 0, '', '', '', 0, '', '', '', 0, '2023-11-13 10:29:37', '', 'unpaid', NULL, NULL, 'unpaid'),
(67, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 310, 0, 750, 0, '2023-11-13', '2023-11-13', 0, 'Bachelor of Engineering', 'Abhijeet', 'Sunil', 'Ghode', 'Male', 8530417169, 'abc@gmail.com', 537821788921, 'salman khan', 'freind', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Maine', 411023, 'deshmukhwadi shivane', 'mumbai', 'Iowa', 411023, '2023-11-13 11:23:52', '', 'unpaid', NULL, NULL, 'unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `registration_history`
--

CREATE TABLE `registration_history` (
  `id` int(11) NOT NULL,
  `profile` varchar(500) NOT NULL,
  `adharphoto` varchar(500) NOT NULL,
  `roomno` int(11) NOT NULL,
  `seater` int(11) NOT NULL,
  `feespm` int(11) NOT NULL,
  `foodstatus` int(11) NOT NULL,
  `stayfrom` date NOT NULL,
  `dob` date NOT NULL,
  `duration` int(11) NOT NULL,
  `course` varchar(500) NOT NULL,
  `firstName` varchar(500) NOT NULL,
  `middleName` varchar(500) NOT NULL,
  `lastName` varchar(500) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `egycontactno` bigint(11) NOT NULL,
  `guardianName` varchar(500) NOT NULL,
  `guardianRelation` varchar(500) NOT NULL,
  `guardianContactno` bigint(11) NOT NULL,
  `corresAddress` varchar(500) NOT NULL,
  `corresCIty` varchar(500) NOT NULL,
  `corresState` varchar(500) NOT NULL,
  `corresPincode` int(11) NOT NULL,
  `pmntAddress` varchar(500) NOT NULL,
  `pmntCity` varchar(500) NOT NULL,
  `pmnatetState` varchar(500) NOT NULL,
  `pmntPincode` int(11) NOT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(500) NOT NULL,
  `subscription_status` enum('paid','unpaid') NOT NULL DEFAULT 'unpaid',
  `subscription_start_date` date DEFAULT NULL,
  `subscription_end_date` date DEFAULT NULL,
  `payment_status` enum('paid','unpaid') NOT NULL DEFAULT 'unpaid',

) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `registration_history`
--

INSERT INTO `registration_history` (`id`, `profile`, `adharphoto`, `roomno`, `seater`, `feespm`, `foodstatus`, `stayfrom`, `dob`, `duration`, `course`, `firstName`, `middleName`, `lastName`, `gender`, `contactno`, `emailid`, `egycontactno`, `guardianName`, `guardianRelation`, `guardianContactno`, `corresAddress`, `corresCIty`, `corresState`, `corresPincode`, `pmntAddress`, `pmntCity`, `pmnatetState`, `pmntPincode`, `postingDate`, `updationDate`, `subscription_status`, `subscription_start_date`, `subscription_end_date`, `payment_status`) VALUES
(27, 'profile/2022-01-28.png', 'adhar/2022-01-29 (1).png', 310, 0, 0, 0, '2023-10-26', '0000-00-00', 0, '', 'Sachin', 'Mirajdar', 'tendulkar', '', 8530417169, 'sachin@gmail.com', 0, '', '', 0, '', '', '', 0, '', '', '', 0, '2023-11-09 09:48:17', '', 'unpaid', NULL, NULL, 'unpaid'),
(29, 'profile/2022-01-29 (1).png', 'adhar/2022-01-29 (1).png', 0, 0, 0, 0, '2023-10-19', '0000-00-00', 0, '', 'Hritik', 'Rakesh', 'Roshan', '', 8530417169, 'hritik@gmail.com', 0, 'qjw', '', 983289, 'deshmukhwadi shivane', '', '', 0, '', '', '', 0, '2023-11-09 09:51:00', '', 'unpaid', NULL, NULL, 'unpaid'),
(31, 'profile/th.jpg', 'adhar/th.jpg', 0, 0, 0, 0, '2023-10-29', '0000-00-00', 0, '', 'Rahul', 'k', 'Malhotra', '', 8530417169, 'rahul@gmail.com', 0, 'salman khan', '', 983289, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', '', '', 0, '2023-11-09 09:59:45', '', 'unpaid', NULL, NULL, 'unpaid'),
(30, 'profile/2022-01-28.png', 'adhar/2022-01-29 (1).png', 0, 0, 0, 0, '2023-10-20', '0000-00-00', 0, '', 'Bhishma', 'Shantanu', 'Sharma', '', 8530417169, 'bhishma@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', '', '', 0, '2023-11-11 08:12:37', '', 'unpaid', NULL, NULL, 'unpaid'),
(37, 'profile/IMG_20220909_214344.jpg', 'adhar/Screenshot_2023_1108_105225.jpg', 112, 0, 0, 0, '2023-11-11', '0000-00-00', 0, '', 'Sonali ', 'Umesh', 'Kulkarni ', '', 8888888888, 'sk@gmail.com', 0, 'Rajendra ', '', 8855223355, '102,kamthe vasti', '', '', 0, '102,kamthe vasti', '', '', 0, '2023-11-12 03:48:18', '', 'unpaid', NULL, NULL, 'unpaid'),
(34, 'profile/IMG-20231103-WA0000.jpg', 'adhar/Screenshot_2023_1108_105225.jpg', 201, 0, 0, 0, '2023-11-11', '0000-00-00', 0, '', 'Omkar ', 'Rajendra', 'Dahiphale ', '', 7058817283, 'omkardahiphale75@gmail.com', 0, 'Rajendra ', '', 8855223355, '102,kamthe vasti', '', '', 0, '102,kamthe vasti', '', '', 0, '2023-11-12 03:53:25', '', 'unpaid', NULL, NULL, 'unpaid'),
(36, 'profile/IMG-20231109-WA0000.jpg', 'adhar/IMG-20231110-WA0000.jpg', 5, 0, 0, 0, '2023-11-11', '0000-00-00', 0, '', 'Ramesh ', 'Revansiddha', 'Saddu', '', 8534879457, 'ganeshsaddu08@gmail.com', 0, 'Revansiddha Saddu', '', 879767, 'Solapur', '', '', 0, 'Solapur', '', '', 0, '2023-11-12 03:53:46', '', 'unpaid', NULL, NULL, 'unpaid'),
(40, 'profile/IMG-20231111-WA0002.jpg', 'adhar/IMG20231111101011.jpg', 21, 0, 0, 0, '2023-11-11', '0000-00-00', 0, '', 'Ajit', 'Amarsing', 'Javheri ', '', 9404481094, 'ajit.javheri@yahoomail.com', 0, 'Amarsing ', '', 7447485485, '1051 Sadashiv peth', '', '', 0, '1051 Sadashiv peth', '', '', 0, '2023-11-12 03:54:41', '', 'unpaid', NULL, NULL, 'unpaid'),
(38, 'profile/IMG-20231108-WA0010.jpg', 'adhar/IMG-20231108-WA0002.jpg', 233, 0, 0, 0, '2023-11-11', '0000-00-00', 0, '', 'Mahantesh ', 'Sharnappa ', 'Nilankar', '', 9767586794, 'ganeshsaddu09@gmail.com', 0, 'Revansiddha Saddu', '', 879767, 'Solapur', '', '', 0, 'Solapur', '', '', 0, '2023-11-12 04:07:25', '', 'unpaid', NULL, NULL, 'unpaid'),
(42, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 269, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'Omkar ', 'Rajendra', 'Dahiphale ', '', 7058817283, 'omkardahiphale75@gmail.com', 0, 'salman khan', '', 3422525, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', '', '', 0, '2023-11-12 04:17:21', '', 'unpaid', NULL, NULL, 'unpaid'),
(43, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/Screenshot 2023-06-09 212506.jpg', 310, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'Omkar ', 'Rajendra', 'Dahiphale ', '', 7058817283, 'omkardahiphale75@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', '', '', 0, '2023-11-12 04:39:50', '', 'unpaid', NULL, NULL, 'unpaid'),
(44, 'profile/Screenshot 2023-06-09 212506.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 200, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'Omkar ', 'Rajendra', 'Dahiphale ', '', 7058817283, 'omkardahiphale75@gmail.com', 9009127873278, 'salman khan', '', 3422525, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', '', '', 0, '2023-11-12 07:28:29', '', 'unpaid', NULL, NULL, 'unpaid'),
(45, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/Screenshot 2023-06-09 212506.jpg', 269, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'Omkar ', 'Rajendra', 'Dahiphale ', '', 7058817283, 'omkardahiphale75@gmail.com', 431122332321, 'salman khan', '', 3422525, 'mumbai', '', '', 0, 'mumbai', '', '', 0, '2023-11-12 07:44:37', '', 'unpaid', NULL, NULL, 'unpaid'),
(46, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/Screenshot 2023-06-09 212506.jpg', 269, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'Omkar ', 'Rajendra', 'Dahiphale ', '', 7058817283, 'omkardahiphale75@gmail.com', 0, 'salman khan', '', 3422525, 'mumbai', '', '', 0, 'mumbai', '', '', 0, '2023-11-12 08:24:15', '', 'unpaid', NULL, NULL, 'unpaid'),
(48, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 310, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', '', '', 0, '2023-11-12 08:26:58', '', 'unpaid', NULL, NULL, 'unpaid'),
(49, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 310, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', 'mumbai', '', 0, '2023-11-12 08:30:29', '', 'unpaid', NULL, NULL, 'unpaid'),
(50, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 310, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', '', '', 0, 'deshmukhwadi shivane', 'mumbai', '', 0, '2023-11-12 08:40:47', '', 'unpaid', NULL, NULL, 'unpaid'),
(47, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/Screenshot 2023-06-09 212506.jpg', 269, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'Omkar ', 'Rajendra', 'Dahiphale ', '', 7058817283, 'omkardahiphale75@gmail.com', 0, 'salman khan', '', 3422525, 'mumbai', '', '', 0, 'mumbai', 'mumbai', '', 411023, '2023-11-12 08:41:46', '', 'unpaid', NULL, NULL, 'unpaid'),
(51, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 21, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', '', '', 788923, 'deshmukhwadi shivane', 'mumbai', '', 788923, '2023-11-12 08:45:39', '', 'unpaid', NULL, NULL, 'unpaid'),
(52, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 21, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', '', '', 788923, 'deshmukhwadi shivane', 'mumbai', '', 788923, '2023-11-12 08:47:11', '', 'unpaid', NULL, NULL, 'unpaid'),
(53, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/Screenshot 2023-06-09 212506.jpg', 310, 0, 0, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 3422525, 'deshmukhwadi shivane', '', '', 411023, 'deshmukhwadi shivane', 'mumbai', '411023', 0, '2023-11-12 09:58:29', '', 'unpaid', NULL, NULL, 'unpaid'),
(54, 'profile/Screenshot 2023-06-09 212506.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 200, 0, 910, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', '', '', 411023, 'deshmukhwadi shivane', 'mumbai', '411023', 0, '2023-11-12 10:00:25', '', 'unpaid', NULL, NULL, 'unpaid'),
(55, 'profile/Screenshot 2023-06-09 212506.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 200, 0, 910, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', '', 411023, 'deshmukhwadi shivane', 'mumbai', 'Idaho', 411023, '2023-11-12 10:10:16', '', 'unpaid', NULL, NULL, 'unpaid'),
(56, 'profile/Screenshot 2023-06-09 212506.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 112, 0, 1300, 0, '2023-11-12', '0000-00-00', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Idaho', 411023, 'deshmukhwadi shivane', 'mumbai', 'Louisiana', 411023, '2023-11-12 10:14:45', '', 'unpaid', NULL, NULL, 'unpaid'),
(57, 'profile/Screenshot 2023-06-09 212506.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 112, 0, 1300, 0, '2023-11-12', '2023-11-12', 0, '', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Idaho', 411023, 'deshmukhwadi shivane', 'mumbai', 'Louisiana', 411023, '2023-11-12 10:18:23', '', 'unpaid', NULL, NULL, 'unpaid'),
(58, 'profile/Screenshot 2023-06-09 212506.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 112, 0, 1300, 0, '2023-11-12', '2023-11-12', 0, 'Master of Computer Application', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 0, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Idaho', 411023, 'deshmukhwadi shivane', 'mumbai', 'Louisiana', 411023, '2023-11-12 10:21:44', '', 'unpaid', NULL, NULL, 'unpaid'),
(59, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 132, 0, 1990, 0, '2023-11-12', '2003-07-22', 0, 'Master of Computer Application', 'karan', 'ram', 'metha', '', 8530417169, 'kr@gmail.com', 457777778995, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Georgia', 411023, 'deshmukhwadi shivane', 'mumbai', 'Kansas', 411023, '2023-11-12 10:25:27', '', 'unpaid', NULL, NULL, 'unpaid'),
(60, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 132, 0, 1990, 0, '2023-11-12', '2003-07-22', 0, 'Master of Computer Application', 'karan', 'ram', 'metha', 'Male', 8530417169, 'kr@gmail.com', 457777778995, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Georgia', 411023, 'deshmukhwadi shivane', 'mumbai', 'Kansas', 411023, '2023-11-12 10:30:02', '', 'unpaid', NULL, NULL, 'unpaid'),
(61, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 132, 0, 1990, 0, '2023-11-12', '2003-07-22', 0, 'Master of Computer Application', 'karan', 'ram', 'metha', 'Male', 8530417169, 'kr@gmail.com', 457777778995, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Georgia', 411023, 'deshmukhwadi shivane', 'mumbai', 'Kansas', 411023, '2023-11-13 07:26:47', '', 'unpaid', NULL, NULL, 'unpaid'),
(64, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 132, 0, 1990, 0, '2023-11-13', '2023-11-13', 0, 'Bachelors In Information Technology', 'karan', 'ram', 'metha', 'Male', 8530417169, 'kr@gmail.com', 21788738832, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Kentucky', 411023, 'deshmukhwadi shivane', 'mumbai', 'Maine', 411023, '2023-11-13 09:54:35', '', 'unpaid', NULL, NULL, 'unpaid'),
(62, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/Screenshot 2023-06-09 212506.jpg', 269, 0, 910, 0, '2023-11-13', '2023-11-13', 0, 'Bachelors In Information Technology', 'karan', 'ram', 'metha', 'Male', 8530417169, 'kr@gmail.com', 121221121212, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Kansas', 411023, 'deshmukhwadi shivane', 'mumbai', 'Colorado', 411023, '2023-11-13 10:18:16', '', 'unpaid', NULL, NULL, 'unpaid'),
(28, 'profile/IMG_20231025_095815.jpg', 'adhar/VID-20231024-WA0006.mp4', 132, 0, 0, 0, '2023-10-26', '0000-00-00', 0, '', 'Ashok vihar ', '9767887542', 'Hahdh', '', 9653434542, 'Asok@gamil.com', 0, 'Hsksksm', '', 1, '7292929', '', '', 0, '', '', '', 0, '2023-11-13 10:28:26', '', 'unpaid', NULL, NULL, 'unpaid'),
(63, 'profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 'adhar/The-Legend-Of-Hanuman-Season-3-Cast-.jpg', 132, 0, 1990, 0, '2023-11-13', '2023-11-13', 0, 'Bachelors In Information Technology', 'karan', 'ram', 'metha', 'Male', 8530417169, 'kr@gmail.com', 21788738832, 'salman khan', '', 9843989039439, 'deshmukhwadi shivane', 'mumbai', 'Kentucky', 411023, 'deshmukhwadi shivane', 'mumbai', 'Maine', 411023, '2023-11-13 10:29:30', '', 'unpaid', NULL, NULL, 'unpaid'),
(65, 'profile/IMG-20231026-WA0017.jpg', '', 201, 0, 0, 0, '2023-10-26', '0000-00-00', 0, '', 'shahrukh', 'king', 'khan', '', 8530417169, '', 0, '', '', 0, '', '', '', 0, '', '', '', 0, '2023-11-13 10:44:46', '', 'unpaid', NULL, NULL, 'unpaid');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `seater` int(11) NOT NULL DEFAULT 1,
  `room_no` int(11) NOT NULL,
  `fees` int(11) NOT NULL,
  `posting_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `seater`, `room_no`, `fees`, `posting_date`) VALUES
(2, 4, 201, 1650, '2020-09-20 04:24:06'),
(3, 2, 200, 910, '2020-09-20 04:33:06'),
(4, 3, 112, 1300, '2020-09-20 04:33:30'),
(5, 5, 132, 1990, '2020-09-20 04:28:52'),
(7, 2, 269, 910, '2022-04-03 14:39:22'),
(8, 1, 310, 750, '2022-04-03 14:41:36'),
(10, 1, 5, 450, '2023-10-26 08:02:55'),
(11, 1, 21, 61, '2023-10-29 04:29:21'),
(12, 1, 233, 32332, '2023-10-30 12:24:11'),
(13, 1, 89, 775, '2023-11-10 08:28:15');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(11) NOT NULL,
  `State` varchar(150) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `State`) VALUES
(1, 'Alabama'),
(2, 'Alaska'),
(3, 'Arizona'),
(4, 'Arkansas'),
(5, 'California'),
(6, 'Colorado'),
(7, 'Connecticut'),
(8, 'Delaware'),
(9, 'Florida'),
(10, 'Georgia'),
(11, 'Hawaii'),
(12, 'Idaho'),
(13, 'Illinois'),
(14, 'Iowa'),
(15, 'Kansas'),
(16, 'Kentucky'),
(17, 'Louisiana'),
(18, 'Maine'),
(19, 'Marryland'),
(20, 'Massachusetts'),
(21, 'Michigan'),
(22, 'Minnesota'),
(23, 'Mississippi'),
(24, 'Missouri'),
(25, 'Nevada'),
(26, 'New Jersey'),
(27, 'New York'),
(28, 'North Carolina'),
(29, 'North Dakota'),
(30, 'Ohio'),
(31, 'Oklahoma'),
(32, 'South Carolina'),
(33, 'South Dakota'),
(34, 'Texas'),
(35, 'Virginia'),
(36, 'Washington');

-- --------------------------------------------------------

--
-- Table structure for table `transaction_details`
--

CREATE TABLE `transaction_details` (
  `id` int(11) NOT NULL,
  `firstName` varchar(500) NOT NULL,
  `middleName` varchar(500) NOT NULL,
  `lastName` varchar(500) NOT NULL,
  `gender` varchar(250) NOT NULL,
  `contactno` bigint(11) NOT NULL,
  `emailid` varchar(500) NOT NULL,
  `merchantId` varchar(250) NOT NULL,
  `merchantTransactionId` varchar(250) NOT NULL,
  `transactionId` varchar(250) NOT NULL,
  `amount` int(11) NOT NULL,
  `state` varchar(250) NOT NULL,
  `responseCode` varchar(250) NOT NULL,
  `paymentInstrumentType` varchar(250) NOT NULL,
  `pgTransactionId` varchar(250) NOT NULL,
  `pgServiceTransactionId` varchar(250) NOT NULL,
  `bankTransactionId` varchar(250) DEFAULT NULL,
  `bankId` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `userEmail` varchar(255) NOT NULL,
  `userIp` varbinary(16) NOT NULL,
  `city` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userId`, `userEmail`, `userIp`, `city`, `country`, `loginTime`) VALUES
(9, 10, 'terry@mail.com', 0x3a3a31, '', '', '2021-03-05 04:12:00'),
(10, 10, 'terry@mail.com', 0x3a3a31, '', '', '2021-03-05 04:14:44'),
(11, 21, 'ross@mail.com', 0x3a3a31, '', '', '2021-03-05 04:19:52'),
(12, 21, 'ross@mail.com', 0x3a3a31, '', '', '2021-03-05 08:53:33'),
(13, 21, 'ross@mail.com', 0x3a3a31, '', '', '2021-03-05 17:35:34'),
(14, 21, 'ross@mail.com', 0x3a3a31, '', '', '2021-03-06 02:43:01'),
(15, 21, 'ross@mail.com', 0x3a3a31, '', '', '2021-03-06 15:18:49'),
(16, 21, 'ross@mail.com', 0x3a3a31, '', '', '2021-03-07 09:35:23'),
(17, 21, 'ross@mail.com', 0x3a3a31, '', '', '2021-03-07 09:59:55'),
(18, 22, 'colin@gmail.com', 0x3a3a31, '', '', '2021-06-16 14:51:24'),
(19, 22, 'colin@gmail.com', 0x3a3a31, '', '', '2021-12-12 15:31:50'),
(20, 22, 'colin@gmail.com', 0x3a3a31, '', '', '2022-04-02 16:01:31'),
(21, 21, 'ross@mail.com', 0x3a3a31, '', '', '2022-04-02 16:52:47'),
(22, 20, 'richards@mail.com', 0x3a3a31, '', '', '2022-04-03 13:15:00'),
(23, 24, 'jennifer@mail.com', 0x3a3a31, '', '', '2022-04-03 14:32:09'),
(24, 24, 'jennifer@mail.com', 0x3a3a31, '', '', '2022-04-03 14:34:17'),
(25, 19, 'bruce@mail.com', 0x3a3a31, '', '', '2022-04-03 14:44:31'),
(26, 27, 'nancy@mail.com', 0x3a3a31, '', '', '2022-04-03 15:00:46'),
(27, 32, 'liamoore@mail.com', 0x3a3a31, '', '', '2022-04-03 15:48:35'),
(28, 32, 'liamoore@mail.com', 0x3a3a31, '', '', '2022-04-03 15:51:34'),
(29, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 04:44:42'),
(30, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 12:54:59'),
(31, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 12:57:51'),
(32, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 12:58:29'),
(33, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-25 13:02:40'),
(34, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-25 13:04:33'),
(35, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-25 13:05:17'),
(36, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 13:08:34'),
(37, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 13:15:25'),
(38, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-25 13:17:27'),
(39, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 13:27:28'),
(40, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 14:31:10'),
(41, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 15:17:10'),
(42, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-25 15:36:25'),
(43, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-25 16:33:51'),
(44, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 04:20:37'),
(45, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 07:06:03'),
(46, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 07:08:02'),
(47, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 07:09:21'),
(48, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 07:10:01'),
(49, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 07:12:38'),
(50, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 07:14:55'),
(51, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 08:06:48'),
(52, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 08:09:57'),
(53, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 08:11:09'),
(54, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 08:28:04'),
(55, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 08:28:42'),
(56, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 08:32:04'),
(57, 33, 'king@gmail.com', 0x3139322e3136382e32332e313638, '', '', '2023-10-26 15:06:53'),
(58, 35, 'a@gmail.com', 0x3139322e3136382e32332e313632, '', '', '2023-10-26 15:10:52'),
(59, 36, 'paa@gmail.com', 0x3139322e3136382e32332e313632, '', '', '2023-10-26 15:14:23'),
(60, 37, 'nitesh@gmail.com', 0x3a3a31, '', '', '2023-10-26 15:15:59'),
(61, 39, 'sachin@gmail.com', 0x3a3a31, '', '', '2023-10-26 15:19:51'),
(62, 42, 'Asok@gamil.com', 0x3139322e3136382e32332e313632, '', '', '2023-10-26 15:22:27'),
(63, 42, 'Asok@gamil.com', 0x3139322e3136382e32332e313632, '', '', '2023-10-26 15:22:28'),
(64, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-26 16:29:25'),
(65, 43, 'hritik@gmail.com', 0x3a3a31, '', '', '2023-10-26 16:32:44'),
(66, 44, 'bhishma@gmail.com', 0x3a3a31, '', '', '2023-10-26 16:37:58'),
(67, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 10:10:37'),
(68, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 12:22:26'),
(69, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 12:22:26'),
(70, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 12:24:14'),
(71, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 12:30:58'),
(72, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 13:43:11'),
(73, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 14:44:19'),
(74, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 14:52:33'),
(75, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-28 15:46:25'),
(76, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-28 17:13:15'),
(77, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-28 17:29:11'),
(78, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-29 02:44:32'),
(79, 34, 'akshay@gmail.com', 0x3a3a31, '', '', '2023-10-29 03:43:25'),
(80, 45, 'rahul@gmail.com', 0x3a3a31, '', '', '2023-10-29 04:16:09'),
(81, 45, 'rahul@gmail.com', 0x3a3a31, '', '', '2023-10-29 04:20:22'),
(82, 45, 'rahul@gmail.com', 0x3a3a31, '', '', '2023-10-29 04:31:30'),
(83, 45, 'rahul@gmail.com', 0x3a3a31, '', '', '2023-10-29 04:38:46'),
(84, 45, 'rahul@gmail.com', 0x3a3a31, '', '', '2023-10-29 04:39:08'),
(85, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-30 11:36:26'),
(86, 33, 'king@gmail.com', 0x3a3a31, '', '', '2023-10-30 16:42:31'),
(87, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-10 10:14:00'),
(88, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-10 14:38:51'),
(89, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-10 14:47:06'),
(90, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-10 14:55:25'),
(91, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-10 14:57:32'),
(92, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-10 15:55:06'),
(93, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-10 15:56:22'),
(94, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-10 16:19:35'),
(95, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 03:17:04'),
(96, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 03:19:06'),
(97, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 03:28:23'),
(98, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 03:58:47'),
(99, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 04:03:09'),
(100, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 04:13:24'),
(101, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 04:19:54'),
(102, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 07:13:42'),
(103, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-11 07:44:45'),
(104, 47, 'omkardahiphale75@gmail.com', 0x3139322e3136382e34332e3838, '', '', '2023-11-11 08:24:35'),
(105, 48, 'ganeshsaddu06@gmail.com', 0x3139322e3136382e34332e31, '', '', '2023-11-11 08:25:03'),
(106, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-11 08:27:42'),
(107, 48, 'ganeshsaddu06@gmail.com', 0x3139322e3136382e34332e31, '', '', '2023-11-11 08:30:19'),
(108, 48, 'ganeshsaddu06@gmail.com', 0x3139322e3136382e34332e31, '', '', '2023-11-11 08:34:16'),
(109, 49, 'sk@gmail.com', 0x3139322e3136382e34332e3838, '', '', '2023-11-11 08:39:44'),
(110, 50, 'ganeshsaddu08@gmail.com', 0x3139322e3136382e34332e31, '', '', '2023-11-11 08:41:01'),
(111, 51, 'ganeshsaddu09@gmail.com', 0x3139322e3136382e34332e31, '', '', '2023-11-11 08:45:06'),
(112, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-11 09:35:51'),
(113, 52, 'omk@gmail.com', 0x3a3a31, '', '', '2023-11-11 11:44:01'),
(114, 53, 'ajit.javheri@yahoomail.com', 0x3139322e3136382e34332e313731, '', '', '2023-11-11 12:08:07'),
(115, 54, 'ganeshs@gmail.com', 0x3a3a31, '', '', '2023-11-11 13:04:53'),
(116, 54, 'ganeshs@gmail.com', 0x3a3a31, '', '', '2023-11-11 13:11:18'),
(117, 54, 'ganeshs@gmail.com', 0x3a3a31, '', '', '2023-11-11 14:10:55'),
(118, 55, 'p@gmail.com', 0x3a3a31, '', '', '2023-11-11 14:11:51'),
(119, 54, 'ganeshs@gmail.com', 0x3a3a31, '', '', '2023-11-11 14:13:55'),
(120, 54, 'ganeshs@gmail.com', 0x3a3a31, '', '', '2023-11-11 14:16:06'),
(121, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-12 04:04:48'),
(122, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-12 04:06:50'),
(123, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-12 04:07:50'),
(124, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-12 04:08:46'),
(125, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-12 04:28:19'),
(126, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-12 04:43:45'),
(127, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-12 07:15:07'),
(128, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-12 07:25:26'),
(129, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-12 08:25:49'),
(130, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-12 08:27:12'),
(131, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-12 08:38:50'),
(132, 56, 'kr@gmail.com', 0x3139322e3136382e3132372e3133, '', '', '2023-11-12 10:53:27'),
(133, 56, 'kr@gmail.com', 0x3139322e3136382e3132372e3133, '', '', '2023-11-12 11:01:01'),
(134, 56, 'kr@gmail.com', 0x3139322e3136382e3132372e3133, '', '', '2023-11-12 11:01:02'),
(135, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-12 11:03:23'),
(136, 56, 'kr@gmail.com', 0x3139322e3136382e3132372e3133, '', '', '2023-11-12 11:08:23'),
(137, 56, 'kr@gmail.com', 0x3139322e3136382e3132372e3133, '', '', '2023-11-12 11:08:23'),
(138, 56, 'kr@gmail.com', 0x3139322e3136382e3132372e3133, '', '', '2023-11-12 11:15:49'),
(139, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-12 12:33:03'),
(140, 47, 'omkardahiphale75@gmail.com', 0x3a3a31, '', '', '2023-11-13 07:19:48'),
(141, 46, 'king1@gmail.com', 0x3a3a31, '', '', '2023-11-13 07:21:44'),
(142, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-13 07:22:58'),
(143, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-13 07:27:06'),
(144, 56, 'kr@gmail.com', 0x3139322e3136382e302e313938, '', '', '2023-11-13 08:53:41'),
(145, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-13 09:20:36'),
(146, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-13 09:37:34'),
(147, 57, 'abc@gmail.com', 0x3a3a31, '', '', '2023-11-13 09:51:40'),
(148, 56, 'kr@gmail.com', 0x3a3a31, '', '', '2023-11-13 09:52:14'),
(149, 57, 'abc@gmail.com', 0x3a3a31, '', '', '2023-11-13 10:22:43'),
(150, 57, 'abc@gmail.com', 0x3a3a31, '', '', '2023-11-13 11:15:12'),
(151, 57, 'abc@gmail.com', 0x3a3a31, '', '', '2023-11-13 11:20:38'),
(152, 57, 'abc@gmail.com', 0x3a3a31, '', '', '2023-11-13 11:22:57');

-- --------------------------------------------------------

--
-- Table structure for table `userregistration`
--

CREATE TABLE `userregistration` (
  `id` int(11) NOT NULL,
  `regNo` varchar(255) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `contactNo` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(45) NOT NULL,
  `passUdateDate` varchar(45) NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `userregistration`
--

INSERT INTO `userregistration` (`id`, `regNo`, `firstName`, `middleName`, `lastName`, `gender`, `contactNo`, `email`, `password`, `regDate`, `updationDate`, `passUdateDate`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(10, 'CA001', 'Terry', 'K.', 'Rodriquez', 'Male', 1325458888, 'terry@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2020-11-05 04:21:33', '', '06-03-2021 10:35:38', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(19, 'CA002', 'Bruce', 'E.', 'Murphy', 'Male', 1346565650, 'bruce@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2020-11-05 04:46:33', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(20, 'CA003', 'Richard', 'J.', 'Summers', 'Male', 1325658800, 'richards@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2020-11-05 04:54:33', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(21, 'CA004', 'Ross', 'S.', 'Daniels', 'Male', 6958545850, 'ross@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2021-03-05 04:19:44', '06-03-2021 10:15:29', '06-03-2021 10:35:38', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(22, 'CA005', 'Colin', 'B', 'Greenwood', 'Male', 7541112050, 'colin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2021-03-06 16:29:57', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(24, 'CA006', 'Jennifer', 'J.', 'Frye', 'Female', 7895555544, 'jennifer@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-03 14:31:50', '', '03-04-2022 08:21:07', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(25, 'CA007', 'Bonnie', 'J.', 'Lamar', 'Female', 4580001014, 'bonnie@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-03 14:51:00', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(26, 'CA008', 'Adam', 'A.', 'Rios', 'Male', 4785690010, 'adam@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-03 14:52:28', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(27, 'CA009', 'Nancy', 'W.', 'Vasquez', 'Female', 3547777770, 'nancy@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-03 14:53:19', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(28, 'CA010', 'Jerry', 'A.', 'Burdine', 'Male', 8520001450, 'jerry@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-03 14:53:58', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(29, 'CA011', 'James', 'K.', 'Fischer', 'Male', 4785470014, 'jamesf@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-03 14:54:44', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(30, 'CA012', 'Darlene', 'D.', 'Kenyon', 'Female', 3547896580, 'darlene@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-03 14:57:04', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(31, 'CA013', 'Joseph', 'H.', 'Peterson', 'Male', 4587450010, 'joseph@mail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-03 14:57:51', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(32, 'CA014', 'Liam', 'K.', 'Moore', 'Male', 7854441014, 'liamoore@mail.com', '5f4dcc3b5aa765d61d8327deb882cf99', '2022-04-03 15:00:04', '', '', NULL, NULL, 0, '2023-10-25 04:43:32', NULL),
(33, '', 'shahrukh', 'king', 'khan', 'Male', 8530417169, 'king@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-25 04:44:36', '', '', NULL, NULL, 0, '2023-10-25 10:14:36', NULL),
(34, '', 'akshay', 'kumar', 'khiladi', 'Male', 8530417152, 'akshay@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-25 13:02:34', '', '', NULL, NULL, 0, '2023-10-25 18:32:34', NULL),
(35, '', 'Pawan ', 'Jskksme', 'Jaksne', 'Male', 9944996655, 'a@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-26 15:10:42', '', '', NULL, NULL, 0, '2023-10-26 20:40:42', NULL),
(36, '', 'Udkdkd', 'Hejdir', 'Hykxk', 'Male', 9831354342, 'paa@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-26 15:14:08', '', '', NULL, NULL, 0, '2023-10-26 20:44:08', NULL),
(37, '', 'Nitesh', 'Sunil', 'Ghode', 'Male', 8530417169, 'nitesh@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-26 15:15:54', '', '', NULL, NULL, 0, '2023-10-26 20:45:54', NULL),
(38, '', 'Prit', 'Ravindra', 'Rajpute', 'Female', 8256349586, 'prit@14', 'dc06698f0e2e75751545455899adccc3', '2023-10-26 15:19:01', '', '', NULL, NULL, 0, '2023-10-26 20:49:01', NULL),
(39, '', 'Sachin', 'Mirajdar', 'tendulkar', 'Male', 8530417169, 'sachin@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-26 15:19:45', '', '', NULL, NULL, 0, '2023-10-26 20:49:45', NULL),
(40, '', 'Raj', 'Mohan ', 'Wankhade', 'Male', 8459969321, 'wankhaderaj@gmail.com', 'dc06698f0e2e75751545455899adccc3', '2023-10-26 15:21:44', '', '', NULL, NULL, 0, '2023-10-26 20:51:44', NULL),
(41, '', 'Ganesh', 'hhjmnsd', 'sddd', 'Male', 8530417169, 'ganeshsaddu@gmail.com', 'Pass@321', '2023-10-26 15:21:58', '', '', NULL, NULL, 0, '2023-10-26 20:51:58', '2023-10-28 19:14:31'),
(42, '', 'Ashok vihar ', '9767887542', 'Hahdh', 'Male', 9653434542, 'Asok@gamil.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-26 15:22:22', '', '', NULL, NULL, 0, '2023-10-26 20:52:22', NULL),
(43, '', 'Hritik', 'Rakesh', 'Roshan', 'Male', 8530417169, 'hritik@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-26 16:32:39', '', '', NULL, NULL, 0, '2023-10-26 22:02:39', NULL),
(44, '', 'Bhishma', 'Shantanu', 'Sharma', 'Male', 8530417169, 'bhishma@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-26 16:37:52', '', '', NULL, NULL, 0, '2023-10-26 22:07:52', NULL),
(45, '', 'Rahul', 'k', 'Malhotra', 'Male', 8530417169, 'rahul@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-10-29 04:16:04', '', '', NULL, NULL, 0, '2023-10-29 09:46:04', NULL),
(46, '', 'shahrukh', 'king', 'khan', 'Male', 8530417169, 'king1@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-11-10 10:13:53', '', '', NULL, NULL, 0, '2023-11-10 15:43:53', NULL),
(47, '', 'Omkar ', 'Rajendra', 'Dahiphale ', 'Male', 7058817283, 'omkardahiphale75@gmail.com', 'f4c5c8f03126a33de0dbea7ccd52aad8', '2023-11-11 08:24:28', '', '', NULL, NULL, 0, '2023-11-11 13:54:28', NULL),
(48, '', 'Ganesh', 'Revansiddha', 'Saddu', 'Male', 8530417169, 'ganeshsaddu06@gmail.com', '22d912d8004b31868870c2c88c047464', '2023-11-11 08:24:46', '', '', NULL, NULL, 0, '2023-11-11 13:54:46', NULL),
(49, '', 'Sonali ', 'Umesh', 'Kulkarni ', 'Female', 8888888888, 'sk@gmail.com', 'f4c5c8f03126a33de0dbea7ccd52aad8', '2023-11-11 08:39:38', '', '', NULL, NULL, 0, '2023-11-11 14:09:38', NULL),
(50, '', 'Ramesh ', 'Revansiddha', 'Saddu', 'Male', 8534879457, 'ganeshsaddu08@gmail.com', '22d912d8004b31868870c2c88c047464', '2023-11-11 08:40:32', '', '', NULL, NULL, 0, '2023-11-11 14:10:32', NULL),
(51, '', 'Mahantesh ', 'Sharnappa ', 'Nilankar', 'Male', 9767586794, 'ganeshsaddu09@gmail.com', '22d912d8004b31868870c2c88c047464', '2023-11-11 08:44:47', '', '', NULL, NULL, 0, '2023-11-11 14:14:47', NULL),
(52, '', 'Omkar', 'Rajebhau', 'Dahiphale', 'Male', 8530417169, 'omk@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-11-11 11:43:50', '', '', NULL, NULL, 0, '2023-11-11 17:13:50', NULL),
(53, '', 'Ajit', 'Amarsing', 'Javheri ', 'Male', 9404481094, 'ajit.javheri@yahoomail.com', '753e91286bebce0ddd63dc0bb65bb7b5', '2023-11-11 12:07:59', '', '', NULL, NULL, 0, '2023-11-11 17:37:59', NULL),
(54, '', 'Ganesh', 'Revansiddh', 'Saddu', 'Male', 8530417169, 'ganeshs@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-11-11 13:04:44', '', '', NULL, NULL, 0, '2023-11-11 18:34:44', NULL),
(55, '', 'Pranav', 'Kailas', 'Bhalerao', 'Male', 8530417169, 'p@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-11-11 14:11:43', '', '', NULL, NULL, 0, '2023-11-11 19:41:43', NULL),
(56, '', 'karan', 'ram', 'metha', 'Male', 8530417169, 'kr@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-11-12 08:25:43', '', '', NULL, NULL, 0, '2023-11-12 13:55:43', NULL),
(57, '', 'Abhijeet', 'Sunil', 'Ghode', 'Male', 8530417169, 'abc@gmail.com', 'f91e15dbec69fc40f81f0876e7009648', '2023-11-13 09:51:35', '', '', NULL, NULL, 0, '2023-11-13 15:21:35', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_meta`
--

CREATE TABLE `user_meta` (
  `user_id` int(11) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee_list`
--
ALTER TABLE `fee_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_status`
--
ALTER TABLE `payment_status`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_details`
--
ALTER TABLE `transaction_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userregistration`
--
ALTER TABLE `userregistration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `fee_list`
--
ALTER TABLE `fee_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `userregistration`
--
ALTER TABLE `userregistration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payment_status`
--
ALTER TABLE `payment_status`
  ADD CONSTRAINT `payment_status_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `registration` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
