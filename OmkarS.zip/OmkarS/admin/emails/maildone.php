<?php
session_start();
include('../includes/dbconn.php');
require('./vendor/autoload.php');
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
$mail = new PHPMailer(true);


$file_location = "../admin/emails"; // Update the path to your uploads folder

if (isset($_GET['id']) && $_GET['ACTION'] == 'EMAIL') {
    $paymentId = $_GET['id'];

    // Fetch payment details from the database using the paymentId
    $aid = $_SESSION['login'];
    $ret = "SELECT * FROM payment_details WHERE id = ? AND emailid = ?";
    $stmt = $mysqli->prepare($ret);
    $stmt->bind_param('is', $paymentId, $aid);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        // Fetch user details for a cleaner display
        $row = $res->fetch_object();
        $firstName = $row->firstName;
        $middleName = $row->middleName;
        $lastName = $row->lastName;

        // Initialize Dompdf
        $dompdf = new Dompdf\Dompdf();

        // Start generating the PDF content as HTML
        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Payment Receipt</title>
            <style>
                body {
                    background: #eee;
                    margin-top: 20px;
                }

                .text-danger strong {
                    color: #9f181c;
                }

                .receipt-main {
                    background: #ffffff none repeat scroll 0 0;
                    border-bottom: 12px solid #333333;
                    border-top: 12px solid #9f181c;
                    margin-top: 50px;
                    margin-bottom: 50px;
                    padding: 40px 30px !important;
                    position: relative;
                    box-shadow: 0 1px 21px #acacac;
                    color: #333333;
                    font-family: open sans;
                }

                .receipt-main p {
                    color: #333333;
                    font-family: open sans;
                    line-height: 1.42857;
                }

                .receipt-footer h1 {
                    font-size: 15px;
                    font-weight: 400 !important;
                    margin: 0 !important;
                }

                .receipt-main::after {
                    background: #414143 none repeat scroll 0 0;
                    content: "";
                    height: 5px;
                    left: 0;
                    position: absolute;
                    right: 0;
                    top: -13px;
                }

                .receipt-main thead {
                    background: #414143 none repeat scroll 0 0;
                }

                .receipt-main thead th {
                    color: #fff;
                }

                .receipt-right h5 {
                    font-size: 16px;
                    font-weight: bold;
                    margin: 0 0 7px 0;
                }

                .receipt-right p {
                    font-size: 12px;
                    margin: 0px;
                }

                .receipt-right p i {
                    text-align: center;
                    width: 18px;
                }

                .receipt-main td {
                    padding: 9px 20px !important;
                    font-size: 13px;
                    font-weight: initial !important;
                }

                .receipt-main td p:last-child {
                    margin: 0;
                    padding: 0;
                }

                .receipt-main td h2 {
                    font-size: 20px;
                    font-weight: 900;
                    margin: 0;
                    text-transform: uppercase;
                }

                .receipt-header-mid .receipt-left h1 {
                    font-weight: 100;
                    margin: 34px 0 0;
                    text-align: right;
                    text-transform: uppercase;
                }

                .receipt-header-mid {
                    margin: 24px 0;
                    overflow: hidden;
                }

                #container {
                    background-color: #dcdcdc;
                }
            </style>
        </head>
        <body>
            <div class="col-md-12">
                <div class="row">
                    <div class="receipt-main col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">
                        <div class="row">
                            <div class="receipt-header">
                                <div class="col-xs-6 col-sm-6 col-md-6">
                                    <div class="receipt-left">
                                        <img class="img-responsive" alt="Company Logo" src="http://localhost/OmkarS/assets/images/guru.png" style="width: 71px; border-radius: 43px;">
                                    </div>
                                </div>
                                <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                                    <div class="receipt-right">
                                        <h5>Company Name.</h5>
                                        <p>+1 3649-6589 <i class="fa fa-phone"></i></p>
                                        <p>company@gmail.com <i class="fa fa-envelope-o"></i></p>
                                        <p>USA <i class="fa fa-location-arrow"></i></p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="receipt-header receipt-header-mid">
                                <div class="col-xs-8 col-sm-8 col-md-8 text-left">
                                    <div class="receipt-right">
                                        <h5>Student Name : <?php echo $firstName . ' ' . $middleName . ' ' . $lastName; ?></h5>
                                        <p><b>Mobile :</b><?php echo $row->contactno; ?></p>
                                        <p><b>Email :</b> <?php echo $row->emailid; ?></p>
                                    </div>
                                </div>
                                <div class="col-xs-4 col-sm-4 col-md-4">
                                    <div class="receipt-left">
                                        <h3>ID # <?php echo $paymentId; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Mode</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="text-left text-success" style="color: black;">Payment for Payment Date:<h2><strong><i class="fa fa-inr"></i><?php echo $paymentDate; ?></strong></h2></td>
                                        <td class="text-left" style="color: black;"><h2><strong><i class="fa fa-inr"></i><?php echo $amount; ?>/-</strong></h2></td>
                                        <td class="text-left" style="color: black;"><h2><strong><i class="fa fa-inr"></i><?php echo $paymentStatus; ?></strong></h2></td>
                                        <td class="text-left" style="color: black;"><h2><strong><i class="fa fa-inr"></i><?php echo $paymentMode; ?></strong></h2></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div class="row">
                            <div class="receipt-header receipt-header-mid receipt-footer">
                                <div class="col-xs-8 col-sm-8 col-md-8 text-left">
                                    <div class="receipt-right">
                                        <p><b>Date :</b> <?php echo $paymentDate; ?></p>
                                        <h5 style="color: rgb(140, 140, 140);">Payment has been successfully done.!</h5>
                                    </div>
                                </div>
                                <div class="col-xs-4 col-sm-4 col-md-4">
                                    <div class="receipt-left">
                                        <h1>Stamp</h1>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </body>
        </html>
        <?php
        $html = ob_get_clean();

        // Load the HTML content into Dompdf
        $dompdf->loadHtml($html);
        $dompdf->set_option('isHtml5ParserEnabled', true);
        $dompdf->set_option('isPhpEnabled', true);

        // Set paper size and rendering options
        $dompdf->setPaper('A4', 'portrait');

        // Render the PDF
        $dompdf->render();

        // Get the PDF content
        $pdfContent = $dompdf->output();

        // Create a unique file name for the PDF
        $file_name = 'invoice_' . $paymentId . '.pdf';
        
        
        // Save the PDF on the server
        file_put_contents($file_location . $file_name, $pdfContent);

        // Email sending code
        try {
            $mail = new PHPMailer(); // Create a new object
            $mail->IsSMTP(); // Enable SMTP
            $mail->SMTPDebug = 2; // Debugging: 1 = errors and messages, 2 = messages only
            $mail->SMTPAuth = true; // Authentication enabled
            $mail->SMTPSecure = 'ssl'; // Secure transfer enabled REQUIRED for GMail
            $mail->Host = "smtp.gmail.com";
            $mail->Port = 465; // or 587
            $mail->IsHTML(true);
            $mail->Username = "myabhyasika@gmail.com";
            $mail->Password = "foxx nnlw lpyv jipr";
            $mail->SetFrom("myabhyasika@gmail.com");
            $mail->Subject = "Test";
            $mail->Body = "hello";
            $mail->AddAddress("ghodeabhijeet18@gmail.com");

        $mail->AddAttachment($file_location . $file_name);
        $mail->MsgHTML("Dear Customer, <br> Please find attached invoice copy. <br> Thank you!");

        if (!$mail->Send()) {
            echo "Mailer Error: " . $mail->ErrorInfo;
        } else {
            echo "Message sent!";
        }
    }
 catch (Exception $e) {
    echo "Mailer Error: " . $mail->ErrorInfo;
}
        // Optional: Delete the PDF file after sending the email
        unlink($file_location . $file_name);
    } else {
        echo 'Payment details not found.';
    }
} else {
    echo 'Invalid request.';
}
?>
