<?php
session_start();
include('../includes/dbconn.php');
require('./vendor/autoload.php'); // Assuming Dompdf is installed in the vendor directory

if (isset($_GET['id'])) {
    $paymentId = $_GET['id'];
    $paymentDate = isset($_GET['date']) ? $_GET['date'] : '';
    $paymentStatus = isset($_GET['status']) ? $_GET['status'] : '';
    $paymentMode = isset($_GET['mode']) ? $_GET['mode'] : '';

    // Fetch payment details from the database using the paymentId
    $aid = $_SESSION['login'];
    $ret = "SELECT * FROM payment_details WHERE id = ? AND emailid = ?";
    $stmt = $mysqli->prepare($ret);
    $stmt->bind_param('is', $paymentId, $aid);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        // Fetch user details for a cleaner display
        $row = $res->fetch_object();
        $firstName = $row->firstName;
        $middleName = $row->middleName;
        $lastName = $row->lastName;

        // Initialize Dompdf
        $dompdf = new Dompdf\Dompdf();
   

        // Start generating the PDF content as HTML
        ob_start();
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Payment Receipt</title>
            <!-- Include Bootstrap CSS -->
            <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
            <!-- Include the CSS files -->
            <link rel="stylesheet" href="../assets/extra-libs/c3/c3.min.css">
            <link rel="stylesheet" href="../assets/libs/chartist/dist/chartist.min.css">
            <link rel="stylesheet" href="../assets/extra-libs/datatables.net-bs4/css/dataTables.bootstrap4.css">
            <link rel="stylesheet" href="../dist/css/style.min.css">

            <style>
                body {
                    background-color: #f8f9fa;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                }

                .header {
                    background-color: #007bff;
                    color: #fff;
                    text-align: center;
                    padding: 20px;
                    border-bottom: 2px solid #fff;
                }

                .company-name {
                    font-size: 24px;
                    font-weight: bold;
                }

                .page {
                    padding: 20px;
                }

                .title {
                    text-align: center;
                    font-size: 30px;
                    font-weight: bold;
                    margin-bottom: 20px;
                    color: #007bff;
                }

                .info {
                    font-size: 18px;
                    margin-bottom: 10px;
                    color: #495057;
                }

                .success-message {
                    text-align: center;
                    font-size: 24px;
                    font-weight: bold;
                    color: #28a745;
                    margin-top: 20px;
                }

                footer {
                    margin-top: 20px;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="company-name"><?php echo $_SERVER['HTTP_HOST']; ?></div>
            </div>
            <div class="container page">
                <!-- <img src="http://localhost/OmkarS/student/profile/The-Legend-Of-Hanuman-Season-3-Cast-.jpg"> -->
                <div class="title">Payment Receipt</div>
                <div class="info"><strong>ID:</strong> <?php echo $paymentId; ?></div>
                <div class="info"><strong>Name:</strong> <?php echo $firstName . ' ' . $middleName . ' ' . $lastName; ?></div>
                <div class="info"><strong>Payment Date:</strong> <?php echo $paymentDate; ?></div>
                <div class="info"><strong>Payment Status:</strong> <?php echo $paymentStatus; ?></div>
                <div class="info"><strong>Payment Mode:</strong> <?php echo $paymentMode; ?></div>
                <div class="success-message">Payment has been successfully done!</div>
            </div>
            <footer><?php include '../includes/footer.php' ?></footer>
        </body>
        </html>
        <?php
        $html = ob_get_clean();

        // Load the HTML content into Dompdf
        $dompdf->loadHtml($html);
        $dompdf->set_option('isRemoteEnabled',true);

        // Set paper size and rendering options
        $dompdf->setPaper('A4', 'portrait');

        // Render the PDF
        $dompdf->render();

        // Set the content type to inform the browser that this is a PDF
        header('Content-Type: application/pdf');

        // Display the PDF in the browser
        $file =  $dompdf->output();
        echo $dompdf->output();
        file_put_contents('generate_pdf',$file);
        require 'class/class.phpmailer.php';
        $mail = new PHPMailer;
        $mail->IsSMTP();
        $mail->Host='smtpout.secureserver.net';

        $mail->Port ='80';
        $mail->SMTPAuth = true;
        $mail->Username = 'myabhyasika@gmail.com';
        $mail->Password = 'ShreeSwamiSamarth@18';
        $mail->SMTPSecure = '';
        $mail->From = 'myabhyasika@gmail.com';
        $mail->FromName = 'myabhyasika@gmail.com';
        $mail->AddAddress = ('ghodeabhijeet18@gmail.com');
        $mail->wordwrap = 50;
        $mail->IsHTML(true);
        $mail->AddAttachment('generate_pdf');
        $mail->Subject ='please find customer details.';
        $mail->Body ='details';

        if ($mail->Send) {
           $message = '<label class="text-success">Customer Details</label>';
        }
        unlink('generate_pdf'); 

        exit();
    } else {
        echo 'Payment details not found.';
    }
} else {
    echo 'Payment ID is missing.';
}
?>
