<?php
session_start();
include('../includes/dbconn.php');
include('../includes/check-login.php');

// Check login and other required validations here.

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $lname = $_POST['lname'];
    $feespm = $_POST['feespm'];
    $payment_date = $_POST['payment_date'];
    $payment_status = $_POST['payment_status'];
    $payment_mode = $_POST['payment_mode'];

    $emailid = $_POST['emailid'];
    $contactno = $_POST['contactno'];

    // Validate data as needed.

    $query = "INSERT INTO payment_details (id,firstName, middleName,lastName, amount, payment_date, payment_status,emailid,contactno,payment_mode) VALUES (?,?,?,?, ?, ?, ?, ?,?,?)";
    $stmt = $mysqli->prepare($query);

    if (!$stmt) {
        die("Prepare failed: " . $mysqli->error);
    }

    $stmt->bind_param("isssisssss",$id, $fname, $mname,$lname, $feespm, $payment_date, $payment_status, $emailid, $contactno,$payment_mode);

    if ($stmt->execute()) {
        echo "<script>alert('Payment record has been successfully inserted!');</script>";
        header("Location: manage-students.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Hostel Management System</title>
    <link href="../assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="../assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <link href="../dist/css/style.min.css" rel="stylesheet">
</head>
<body>
<div class="modal fade" id="AddnewPaymentModal" tabindex="-1" role="dialog" aria-labelledby="AddnewPaymentModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="AddnewPaymentModal">Student</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <form method="POST" >
                <?php	
                $aid=$_GET['id'];
                    $ret="select * from registration where id=?";
                        $stmt= $mysqli->prepare($ret) ;
                    $stmt->bind_param('i',$aid);
                    $stmt->execute();
                    $res=$stmt->get_result();

                    while($row=$res->fetch_object())
                    {
                        ?>
                         <input type="text" name="id" id="id" value="<?php echo $row->id;?>" class="form-control" readonly>
                         <input type="text" name="fname" id="fname" value="<?php echo $row->firstName;?>" class="form-control" readonly><br>
                         <input type="text" name="mname" id="mname" value="<?php echo $row->middleName;?>" class="form-control" readonly><br>
                         <input type="text" name="lname" id="lname" value="<?php echo $row->lastName;?>" class="form-control" readonly><br>


                         <input type="text" name="emailid" id="mname" value="<?php echo $row->emailid;?>" class="form-control" readonly><br>
                         <input type="number" name="contactno" id="mname" value="<?php echo $row->contactno;?>" class="form-control" readonly><br>
                         <input type="number" name="feespm" id="feespm" value="<?php echo $row->feespm;?>" class="form-control" readonly><br>
                        <?php
                      
                            } ?>
                            
                    <!-- Input fields for student data -->
                    
                    
                   
                    <!-- Input field for payment details -->
                   
                    <input type="date" name="payment_date" id="payment_date" class="form-control" required value="<?php echo date('Y-m-d'); ?>"><br>
                    <input type="text" name="payment_status" id="payment_status" value="paid" class="form-control" readonly><br>
                    <select name="payment_mode" id="payment_mode" class="form-control" required>
                    <option value="online">Online</option>
    
                    <option value="cash">Cash</option>
    
</select><br>
                    
                    <!-- Submit button -->
                    <button type="submit" name="submit" class="btn btn-success">Submit</button>
                   
                </form>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>

            </div>
            
        </div>
    </div>
</div>
<!-- Add a button or link to trigger the modal -->
<!-- Include necessary JavaScript and dependencies -->
</body>
</html>



    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <?php include 'includes/navigation.php'?>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <?php include 'includes/sidebar.php'?>
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">


                    <div class="col-7 align-self-center">
                    <!-- <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Full Details</h4> -->
					
                        <div class="d-flex align-items-center">
                            <!-- <nav aria-label="breadcrumb">
                                
                            </nav> -->
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
				

                <!--Table Column -->
                
                <div class="card">
                 
                 <div class="card-body">
                 
                    <div class="row">
                    
                    <div class="table-responsive">
                                  <table id="zctb" class="table table-striped table-bordered no-wrap">

                                      <tbody>
                                        

                                      <?php	
                                      
                                      $id=$_GET['id'];
                                        $ret="SELECT * from registration where id=?";
                                        $stmt= $mysqli->prepare($ret) ;
                                    $stmt->bind_param('i',$id);
                                    $stmt->execute() ;//ok
                                    $res=$stmt->get_result();
                                    //$cnt=1;
                                    while($row=$res->fetch_object())
                                    {
                                              ?>

                                        <tr>
                                            
                                        
                                        <td><img src='../student/<?php echo $row->profile; ?>' height='90px' width='90px'></td>

                                            <td><b>Name : <?php echo $row->firstName;?> <?php echo $row->middleName;?> <?php echo $row->lastName;?></b><br>
                                            <?php echo $row->dob;?><br>
                                            <a href="../student/<?php echo $row->adharphoto;?>">Aadhar Photo</a>
											<b>Contact Number :</b>
                                         <?php echo $row->contactno;?>
										 <?php echo $row->emailid;?>
										 <td><b>Seat no :</b></td>
                                          <td><?php echo $row->roomno;?></td>

                                            
                                        
                                        </td>
                                       

                                        </tr>
                                          <?php } ?>

                                      </tbody>
                                  </table>
                                 
                              </div>
                    
                    
                    </div>
                 
                 
                 </div>
               
               
               </div>


			   <div class="container-fluid">

                <!-- Table Starts -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">

                            <a href="#" data-toggle="modal" data-target="#AddnewPaymentModal"><button type="button" class="btn btn-block btn-md btn-success">Add New Payment</button></a>                            <hr>
                                <div class="table-responsive">
                                    <table id="zero_config" class="table table-striped table-hover table-bordered no-wrap">
                                    <thead class="thead-dark">
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Payment Date</th>
                                                
                                                <th>Payment Status</th>
                                                <th>Payment Mode</th>
                                               
                                            </tr>
                                        </thead>
                                        <tbody>
                                    <?php	
                                      
                                      $id=$_GET['id'];
                                        $ret="SELECT * from payment_details where id=?";
                                        $stmt= $mysqli->prepare($ret) ;
                                    $stmt->bind_param('i',$id);
                                    $stmt->execute() ;//ok
                                    $res=$stmt->get_result();
                                    //$cnt=1;
                                    while($row=$res->fetch_object())
                                    {
                                              ?>

                                        <tr>
                                        <td><?php echo $row->id;?>
                                        <td><?php echo $row->firstName;?> <?php echo $row->middleName;?> <?php echo $row->lastName;?>
                                        <td><?php echo $row->payment_date;?>
                                        <td><?php echo $row->payment_status;?>
                                        <td><?php echo $row->payment_mode;?>

                                        </tr>



                                        

                                          
                                          


                                          


                                          <?php } ?>
</tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              <!-- Table column end -->

            </div>


			
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <?php include '../includes/footer.php' ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->


	<script>
    // JavaScript to handle student deletion
    $(document).on("click", "#AddnewPaymentModal", function() {
        // Perform the deletion here, e.g., via AJAX
        var studentId = /* Get the student ID to be deleted */;
        
        // Replace the following code with your actual AJAX call to delete the student record
        $.ajax({
            url: "delete-student.php?id=" + studentId, // Your server-side script for deletion
            method: "GET",
            success: function(response) {
                if (response === "success") {
                    alert("Student record deleted successfully.");
                    // Optionally, refresh the page or remove the row from the table
                } else {
                    alert("Failed to delete student record.");
                }
            },
            error: function() {
                alert("Error while communicating with the server.");
            }
        });
    });
</script>
<script>
  // Get the current date in the format YYYY-MM-DD
  var today = new Date();
  var year = today.getFullYear();
  var month = (today.getMonth() + 1).toString().padStart(2, '0'); // Add 1 to the month since it's zero-based
  var day = today.getDate().toString().padStart(2, '0');
  var currentDate = year + '-' + month + '-' + day;

  // Set the date input field to today's date
  document.getElementById('stayf').value = currentDate;
</script>




    <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <!-- apps -->
    <script src="../dist/js/app-style-switcher.js"></script>
    <script src="../dist/js/feather.min.js"></script>
    <script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <script src="../assets/extra-libs/c3/d3.min.js"></script>
    <script src="../assets/extra-libs/c3/c3.min.js"></script>
    <script src="../assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="../dist/js/pages/dashboards/dashboard1.min.js"></script>

</body>

</html>