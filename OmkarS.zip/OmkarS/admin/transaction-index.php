<?php
session_start();
include('../includes/dbconn.php');
include('../includes/check-login.php');
check_login();
?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Hostel Management System</title>
    <!-- Custom CSS -->
    <link href="../assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="../assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
     <!-- This page plugin CSS -->
     <link href="../assets/extra-libs/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../dist/css/style.min.css" rel="stylesheet">

</head>

<body>
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <?php include 'includes/navigation.php'?>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <?php include 'includes/sidebar.php'?>
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                    <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Paid and Unpaid of <?php echo date("F"); ?></h4>
                        <div class="d-flex align-items-center">
                            <!-- <nav aria-label="breadcrumb">
                                
                            </nav> -->
                           
                        </div>
                    </div>
                    
                </div>

            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
            <div class="row mb-2">
    <div class="col-12">
        <button class="btn btn-success" onclick="filterTable('paid')">All</button>
        <button class="btn btn-danger" onclick="filterTable('unpaid')">Unpaid</button>
    </div>
</div>

                <!-- Table Starts -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                            <hr>
                                <div class="table-responsive">
                                    <table id="zero_config" class="table table-striped table-hover table-bordered no-wrap">
                                    <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                   
                                    <th>Payment Status</th>
                                    <th>Payment Mode</th>
                                    <th>Contact No</th>
                                    <th>Email</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Assuming you've already established a database connection

                                // Get the current month and year
                                $currentMonth = date("m");
                                $currentYear = date("Y");

                                // SQL query to fetch students and their payment status for the current month
                                $sql = "SELECT registration.*, IFNULL(payment_details.payment_status, 'unpaid') AS payment_status,
                                payment_details.payment_date,
                                 payment_details.payment_mode
                                        FROM registration
                                        LEFT JOIN payment_details ON registration.id = payment_details.id 
                                        AND MONTH(payment_details.payment_date) = ? 
                                        AND YEAR(payment_details.payment_date) = ?";

                                $stmt = $mysqli->prepare($sql);
                                $stmt->bind_param("ss", $currentMonth, $currentYear);
                                $stmt->execute();
                                $result = $stmt->get_result();

                                // Loop through the result and display the list
                                // Loop through the result and display the list
                                // Loop through the result and display the list
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['firstName'] . ' ' . $row['lastName'] . "</td>";

    // Determine the color based on payment status
    $statusColor = (isset($row['payment_status']) && $row['payment_status'] == 'paid') ? 'green' : 'red';

    // Echo the table cells for payment status with inline style for color
    echo "<td style='color: $statusColor;'>" . (isset($row['payment_status']) ? $row['payment_status'] : '') . "</td>";

    echo "<td>" . (isset($row['payment_mode']) ? $row['payment_mode'] : '') . "</td>";
    echo "<td><a href='tel:" . (isset($row['contactno']) ? $row['contactno'] : '') . "'>" . (isset($row['contactno']) ? $row['contactno'] : '') . "</a></td>";

    echo "<td>" . (isset($row['emailid']) ? $row['emailid'] : '') . "</td>";
    echo "<td>" . (isset($row['payment_date']) ? $row['payment_date'] : '') . "</td>";
    echo '<td> <a href="manage-fees.php?id='  . $row['id'] . '" title="fees"><button type="button" class="btn btn-success">
        <i class="fas fa-rupee-sign mr-2"></i> Fees
    </button></a></td>';
    echo "</tr>";
}


                                ?>
                            </tbody>
                        </table>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Table Ends -->

            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <?php include '../includes/footer.php' ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <!-- ... (your existing code) ... -->

<!-- Add this JavaScript function below your existing scripts -->
<script>
    function filterTable(status) {
        var table = $('#zero_config').DataTable();

        // Clear any existing filters
        table.search('').columns().search('').draw();

        // Set the filter based on the status (paid or unpaid)
        if (status === 'paid') {
            table.column(2).search('paid').draw();
        } else if (status === 'unpaid') {
            table.column(2).search('unpaid').draw();
        }
    }
</script>
<!-- ... (your existing code) ... -->

    <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <!-- apps -->
    <script src="../dist/js/app-style-switcher.js"></script>
    <script src="../dist/js/feather.min.js"></script>
    <script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <script src="../assets/extra-libs/c3/d3.min.js"></script>
    <script src="../assets/extra-libs/c3/c3.min.js"></script>
    <script src="../assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="../dist/js/pages/dashboards/dashboard1.min.js"></script>
    <script src="../assets/extra-libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../dist/js/pages/datatable/datatable-basic.init.js"></script>

</body>

</html>