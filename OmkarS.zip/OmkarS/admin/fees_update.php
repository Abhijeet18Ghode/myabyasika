<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id']) && isset($_POST['payment_status'])) {
    include('../includes/dbconn.php');

    $studentId = $_POST['id'];
    $paymentStatus = $_POST['payment_status'];

    // You can add additional validation and security checks here if needed

    // Perform a database query to update the payment status
    $updateSql = "UPDATE registration SET payment_status = ? WHERE id = ?";
    $updateStmt = $mysqli->prepare($updateSql);
    $updateStmt->bind_param('si', $paymentStatus, $studentId);

    if ($updateStmt->execute()) {
        // The payment status was updated successfully

        // You can add logic here to check for specific conditions to automatically set the status to "unpaid"
        // For example, if a certain period has passed, update the status to "unpaid"

        // Respond with a success message
        $response = ['success' => true];
    } else {
        // An error occurred while updating the payment status
        $response = ['success' => false, 'message' => 'Failed to update payment status.'];
    }

    echo json_encode($response);
} else {
    // Invalid or incomplete request, return a 400 Bad Request response
    http_response_code(400);
}
?>


<?php
    session_start();
    include('../includes/dbconn.php');
    include('../includes/check-login.php');
    check_login();

    // if (isset($_GET['del'])) {
    //     $id = intval($_GET['del']);
    //     $adn = "DELETE from registration where id=?";
    //     $stmt = $mysqli->prepare($adn);
    //     $stmt->bind_param('i', $id);
        
    //     if ($stmt->execute()) {
    //         echo "<script>alert('Record has been deleted');</script>";
    //     } else {
    //         echo "<script>alert('Failed to delete record');</script>";
    //     }
        
    //     $stmt->close();
    // }
    


    if (isset($_GET['del'])) {
        $id = intval($_GET['del']);
    
        // Select the entry to be deleted so that it can be moved to history
        $selectSql = "SELECT * FROM registration WHERE id = ?";
        $selectStmt = $mysqli->prepare($selectSql);
        $selectStmt->bind_param('i', $id);
        
        if ($selectStmt->execute()) {
            $result = $selectStmt->get_result();
            if ($row = $result->fetch_object()) {
                // Insert the selected entry into the history table
                $insertSql = "INSERT INTO registration_history (roomno, firstName, middleName, lastName, stayfrom, contactno, profile) VALUES (?, ?, ?, ?, ?, ?, ?)";
                $insertStmt = $mysqli->prepare($insertSql);
                $insertStmt->bind_param('sssssss', $row->roomno, $row->firstName, $row->middleName, $row->lastName, $row->stayfrom, $row->contactno, $row->profile);
                
                if ($insertStmt->execute()) {
                    // Entry inserted into history, now delete it from the registration table
                    $deleteSql = "DELETE FROM registration WHERE id = ?";
                    $deleteStmt = $mysqli->prepare($deleteSql);
                    $deleteStmt->bind_param('i', $id);
    
                    if ($deleteStmt->execute()) {
                        echo "<script>alert('Record has been deleted and moved to history');</script>";
                    } else {
                        echo "<script>alert('Failed to delete record');</script>";
                    }
                    
                    $deleteStmt->close();
                } else {
                    echo "<script>alert('Failed to insert record into history');</script>";
                }
                
                $insertStmt->close();
            }
        } else {
            echo "<script>alert('Failed to fetch record for deletion');</script>";
        }
        
        $selectStmt->close();
    }
    

?>

<!DOCTYPE html>
<html dir="ltr" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/images/favicon.png">
    <title>Hostel Management System</title>
    <!-- Custom CSS -->
    <link href="../assets/extra-libs/c3/c3.min.css" rel="stylesheet">
    <link href="../assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
     <!-- This page plugin CSS -->
     <link href="../assets/extra-libs/datatables.net-bs4/css/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="../dist/css/style.min.css" rel="stylesheet">

    <script language="javascript" type="text/javascript">
    var popUpWin=0;
    function popUpWindow(URLStr, left, top, width, height){
        if(popUpWin) {
         if(!popUpWin.closed) popUpWin.close();
            }
            popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+510+',height='+430+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
        }
    </script>

</head>

<body>






    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    <div class="preloader">
        <div class="lds-ripple">
            <div class="lds-pos"></div>
            <div class="lds-pos"></div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper" data-theme="light" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
        data-sidebar-position="fixed" data-header-position="fixed" data-boxed-layout="full">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar" data-navbarbg="skin6">
            <?php include 'includes/navigation.php'?>
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <aside class="left-sidebar" data-sidebarbg="skin6">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar" data-sidebarbg="skin6">
                <?php include 'includes/sidebar.php'?>
            </div>
            <!-- End Sidebar scroll-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-7 align-self-center">
                    <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Abhyasika Student Management</h4>
                        <div class="d-flex align-items-center">
                            <!-- <nav aria-label="breadcrumb">
                                
                            </nav> -->
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
    <!-- Table Starts -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-subtitle">Displaying all the registered students list.</h6>
                    <div class="table-responsive">
                        <table id="zero_config" class="table table-striped table-hover table-bordered no-wrap">
                            <thead class="thead-dark">
                                <tr>
                                    <th>#</th>
                                    <th>Profile</th>
                                    <th>Seat No.</th>
                                    <th>Student's Name</th>
                                    <th>Admitted From</th>
                                    <th>Contact</th>
                                    <th>Payment Status</th> <!-- New column for Payment Status -->
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $aid = $_SESSION['id'];
                                $ret = "SELECT * from registration";
                                $stmt = $mysqli->prepare($ret);
                                $stmt->execute(); // OK
                                $res = $stmt->get_result();
                                $cnt = 1;
                                while ($row = $res->fetch_object()) {
                                    ?>
                                    <tr>
                                        <td><?php echo $cnt; ?></td>
                                        <td><img src='../student/<?php echo $row->profile; ?>' height='70px' width='70px'></td>
                                        <td><?php echo $row->roomno; ?></td>
                                        <td><?php echo $row->firstName; ?> <?php echo $row->middleName; ?> <?php echo $row->lastName; ?></td>
                                        <td><?php echo $row->stayfrom; ?></td>
                                        <td><?php echo $row->contactno; ?></td>
                                       <!-- Add the new column header for Payment Status -->
<th>Payment Status</th>

<!-- Display Payment Status in each row -->
<td>
    <select id="paymentStatus<?php echo $row->id; ?>">
        <option value="pending" <?php if ($row->payment_status == "pending") echo "selected"; ?>>Pending</option>
        <option value="paid" <?php if ($row->payment_status == "paid") echo "selected"; ?>>Paid</option>
    </select>
    <button onclick="updatePaymentStatus(<?php echo $row->id; ?>)">Update</button>
</td>

                                        <!-- <td>
                                            <a href="students-profile.php?id=<?php echo $row->id; ?>" title="View Full Details"><i class="icon-size-fullscreen"></i></a>
                                            <a href="manage-students.php?del=<?php echo $row->id; ?>" title="Delete Record" data-toggle="modal" data-target="#deleteStudentModal"><i class="icon-close" style="color:red;"></i></a>
                                            <a href="manage-fees.php?id=<?php echo $row->id; ?>" title="fees"><i class="icon-close" style="color:red;"></i></a>
                                        </td> -->
                                    </tr>
                                    <?php
                                    $cnt = $cnt + 1;
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Table Ends -->
</div>

                
                <!-- Table Ends -->

            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            <?php include '../includes/footer.php' ?>
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Page wrapper  -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script>
    // JavaScript to handle student deletion
    $(document).on("click", "#deleteStudentButton", function() {
        // Perform the deletion here, e.g., via AJAX
        var studentId = /* Get the student ID to be deleted */;
        
        // Replace the following code with your actual AJAX call to delete the student record
        $.ajax({
            url: "delete-student.php?id=" + studentId, // Your server-side script for deletion
            method: "GET",
            success: function(response) {
                if (response === "success") {
                    alert("Student record deleted successfully.");
                    // Optionally, refresh the page or remove the row from the table
                } else {
                    alert("Failed to delete student record.");
                }
            },
            error: function() {
                alert("Error while communicating with the server.");
            }
        });
    });
</script>


<script>
    // Wait for the document to be fully loaded
    document.addEventListener("DOMContentLoaded", function () {
        // Find the button element by its ID
        var openButton = document.getElementById("SalaryMonthModal");

        // Find the modal element by its ID
        var salaryMonthModal = document.getElementById("SalaryMonthModal");

        // When the button is clicked, show the modal
        openButton.addEventListener("click", function () {
            // Use Bootstrap's modal methods to show the modal
            if (typeof $(salaryMonthModal).modal === "function") {
                $(salaryMonthModal).modal("show");
            }
        });
    });
</script>


<script>
    function updatePaymentStatus(studentId) {
        var selectedPaymentStatus = document.getElementById("paymentStatus" + studentId).value;
        var url = "update-payment-status.php"; // Replace with the actual PHP script URL

        var data = {
            student_id: studentId,
            payment_status: selectedPaymentStatus
        };

        // Send an AJAX request to update the payment status
        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.success) {
                    alert("Payment status updated successfully.");
                    // Optionally, refresh the page or provide visual feedback to the user
                } else {
                    alert("Failed to update payment status.");
                }
            })
            .catch((error) => {
                console.error("Error:", error);
            });
    }
</script>


    <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
    <script src="../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <!-- apps -->
    <script src="../dist/js/app-style-switcher.js"></script>
    <script src="../dist/js/feather.min.js"></script>
    <script src="../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <script src="../assets/extra-libs/c3/d3.min.js"></script>
    <script src="../assets/extra-libs/c3/c3.min.js"></script>
    <script src="../assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="../dist/js/pages/dashboards/dashboard1.min.js"></script>
    <script src="../assets/extra-libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="../dist/js/pages/datatable/datatable-basic.init.js"></script>

</body>

</html>