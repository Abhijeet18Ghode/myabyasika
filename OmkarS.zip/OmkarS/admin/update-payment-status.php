<?php
// Include your database connection file (e.g., dbconn.php)
include('../includes/dbconn.php');
if (isset($_POST['submit'])) {
    // Retrieve and sanitize user input
    $amount = mysqli_real_escape_string($mysqli, $_POST['amount']);
    $payment_status = mysqli_real_escape_string($mysqli, $_POST['payment_status']);
    $payment_date = mysqli_real_escape_string($mysqli, $_POST['payment_date']);
    $student_id = mysqli_real_escape_string($mysqli, $_POST['student_id']);

    // Validate and sanitize user input as needed

    // Prepare and execute the database query to insert payment information
    $query = "INSERT INTO payment_status (firstName, middleName, lastName, gender, contactno, emailid, amount, student_id, payment_status, payment_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $mysqli->prepare($query);

    if (!$stmt) {
        die("Prepare failed: " . $mysqli->error);
    }

    // You need to fetch the student's information from the registration table using the student_id
    // This part can be similar to the previous code I provided for fetching student details

    // Bind parameters and execute the query
    // ...

    if ($stmt->execute()) {
        echo "<script>alert('Payment information has been successfully inserted into the database!');</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    // Optionally, you can redirect the user to another page after processing the form.
    // header("Location: success.php");
} else {
    // Handle cases where the form was not submitted
    // Redirect or display an error message as needed
}
?>
