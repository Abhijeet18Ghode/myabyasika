<!-- Sidebar navigation-->
<nav class="sidebar-nav">

    <ul id="sidebarnav">
    
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="dashboard.php"
        aria-expanded="false"><i data-feather="home" class="feather-icon"></i><span
         class="hide-menu">Dashboard</span></a></li>

        <li class="list-divider"></li>

        <li class="nav-small-cap"><span class="hide-menu">Features</span></li>
        
        

        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="manage-students.php"
        aria-expanded="false"><i class="fas fa-users"></i><span
        class="hide-menu">Abhyasika Students</span></a></li>

   

        

        
        <!-- <a href="manage-fees.php?id=<?php echo $row->id; ?>" title="fees" data-toggle="modal" data-target="#SalaryMonthModal"><i class="icon-close" style="color:red;"></i></a> -->

        <!-- <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="register-student.php"
        aria-expanded="false"><i class="fas fa-user-plus"></i><span
        class="hide-menu">Register Student</span></a></li> -->
<!-- 
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="view-students-acc.php"
        aria-expanded="false"><i class="fas fa-user-circle"></i><span
        class="hide-menu">View Student Acc.</span></a></li> -->

        <!-- <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="bookings.php"
        aria-expanded="false"><i class="fas fa-user-plus"></i><span
        class="hide-menu">Register Student</span></a></li> -->

        

        

        <!-- <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="manage-courses.php"
        aria-expanded="false"><i class="fas fa-book"></i><span
        class="hide-menu">Manage Courses</span></a></li> -->
       
       
       


        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="transaction-index.php"
        aria-expanded="false"><i class="fas fa-credit-card"></i><span
        class="hide-menu">Transaction</span></a></li>


        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="manage-rooms.php"
        aria-expanded="false"><i class="fas fa-table"></i><span
        class="hide-menu">Manage Seats</span></a></li>
        
        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="#"
        aria-expanded="false"><i class="fa fa-envelope" aria-hidden="true"></i><span
        class="hide-menu">Notice</span></a></li>

        <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href="history.php"
        aria-expanded="false"><i class="fa fa-folder-open" aria-hidden="true"></i><span
        class="hide-menu">History</span></a></li>


     
  


        <!-- <li class="sidebar-item"> <a class="sidebar-link sidebar-link" href=""
        aria-expanded="false"><i class="fas fa-bell"></i><span
        class="hide-menu">Add Notice</span></a></li> -->
                           
    </ul>
</nav>
<!-- End Sidebar navigation -->