<?php
echo $r=$_GET['response'];

?>