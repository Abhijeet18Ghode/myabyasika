<?php

// Verify the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Read the incoming JSON data
    $rawData = file_get_contents('php://input');
    $jsonData = json_decode($rawData, true);

    if ($jsonData !== null) {
        // Verify the data received from PhonePe
        // You should implement your own verification logic here
        // Ensure the request is legitimate and that the payment was successful

        // For example, you can check the transaction status
        if ($jsonData['status'] === 'SUCCESS') {
            // Payment was successful
            // You can process the successful payment here
            // You may want to update your database or perform other actions

            // Respond to PhonePe with a success message (HTTP 200 OK)
            http_response_code(200);
            echo 'Payment Successful';
        } else {
            // Payment was not successful
            // Handle the failure accordingly

            // Respond to PhonePe with an error (HTTP 400 Bad Request)
            http_response_code(400);
            echo 'Payment Failed';
        }
    } else {
        // Invalid JSON data
        http_response_code(400);
        echo 'Invalid JSON Data';
    }
} else {
    // Invalid request method
    http_response_code(405);
    echo 'Method Not Allowed';
}
